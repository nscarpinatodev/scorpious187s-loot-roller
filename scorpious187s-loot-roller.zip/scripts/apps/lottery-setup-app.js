/**
 * LotterySetupApp — GM interface for sorting generated loot.
 *
 * Shows all rolled items and coins. GM assigns each item to one of:
 *   lottery — players roll off for it
 *   stash   — goes directly to the party stash actor
 *   discard — dropped from this session
 *
 * Destinations are tracked in this._destinations (idx → string) rather than
 * radio inputs, because Foundry's form event handling interferes with
 * radio change events in ApplicationV2.
 */

import { LotteryManager } from "../lottery-manager.js";
import { LotteryGMApp }   from "./lottery-gm-app.js";
import { LootListManager } from "../loot-list-manager.js";
import { formatCoins }    from "../currency-helper.js";
import { LootRoller }     from "../api.js";
import { ItemDetailApp }  from "./item-detail-app.js";
import { bindRowClicks }  from "../row-click.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

/**
 * Return a generic display label for a mystified item based on its type.
 * Used as system.unidentified.name so dnd5e hides the real item name.
 */
function _unidentifiedLabel(data) {
  const sub = data.system?.type?.value ?? "";
  switch (data.type) {
    case "weapon":
      return "Unidentified Weapon";
    case "consumable":
      if (sub === "scroll") return "Unidentified Scroll";
      if (sub === "potion") return "Unidentified Potion";
      if (sub === "wand")   return "Unidentified Wand";
      if (sub === "rod")    return "Unidentified Rod";
      return "Unidentified Item";
    case "equipment":
      if (sub === "armor")  return "Unidentified Armor";
      if (sub === "shield") return "Unidentified Shield";
      return "Unidentified Item";
    default:
      return "Unidentified Item";
  }
}

export class LotterySetupApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "lottery-setup-app",
    classes: ["loot-roller", "lottery-setup"],
    tag: "form",
    form: { handler: LotterySetupApp.#onSubmit, submitOnChange: false, closeOnSubmit: false },
    window: { title: "LOOTROLLER.lottery.setupTitle", icon: "fa-solid fa-dice-d20", resizable: true },
    position: { width: 560, height: "auto", top: 100 },
  };

  static PARTS = {
    form: { template: "modules/scorpious187s-loot-roller/templates/lottery-setup.hbs" },
  };

  /** @param {{ coins: object, items: Array }} lootResult */
  constructor(lootResult, options = {}) {
    super(options);
    this._lootResult = lootResult;
    /** @type {Record<number, "lottery"|"stash"|"discard">} */
    this._destinations = {};
    /** @type {Record<number, boolean>} idx → true = mystified (unidentified for players) */
    this._mystified = {};
    /** @type {"equal"|"stash"} */
    this._currencyMode = game.settings.get("scorpious187s-loot-roller", "currencyDistribution") ?? "equal";

    // Seed mystified state from item data (rare+ items auto-mystified by resolveItems).
    // dnd5e: system.identified === false
    // PF2e:  system.identification.status === "unidentified"
    lootResult.items.forEach((item, idx) => {
      if (item.system?.identified === false ||
          item.system?.identification?.status === "unidentified") {
        this._mystified[idx] = true;
      }
    });
  }

  async _prepareContext(options) {
    const { coins, items } = this._lootResult;
    const stashUuid  = game.settings.get("scorpious187s-loot-roller", "partyStashActor");
    const stashActor = stashUuid ? await fromUuid(stashUuid) : null;

    return {
      coins,
      formattedCoins: formatCoins(coins),
      hasCoins:       Object.values(coins).some((v) => v > 0),
      currencyMode:   this._currencyMode,
      items: items.map((item, idx) => ({
        idx,
        name:       item.name ?? "Unknown Item",
        img:        item.img  ?? "icons/svg/item-bag.svg",
        rarity:     item.system?.traits?.rarity ?? item.system?.rarity ?? item.rarity ?? "",
        level:      item.system?.level?.value   ?? null,
        stub:       !!item.stub,
        dest:       this._destinations[idx] ?? "lottery",
        mystified:  this._mystified[idx] ?? false,
        sourceUuid: item._sourceUuid ?? item.uuid ?? null,
      })),
      stashActorName: stashActor?.name ?? null,
      hasStash:       !!stashActor,
    };
  }

  _onRender(context, options) {
    super._onRender?.(context, options);

    // Destination buttons
    this.element.querySelectorAll("[data-action=set-dest]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const idx  = parseInt(btn.dataset.idx);
        const dest = btn.dataset.dest;
        this._destinations[idx] = dest;
        btn.closest(".item-destination").querySelectorAll(".dest-btn").forEach((b) => {
          b.classList.toggle("selected", b === btn);
        });
      });
    });

    // Mystify toggle buttons
    this.element.querySelectorAll("[data-action=toggle-mystify]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const idx = parseInt(btn.dataset.idx);
        this._mystified[idx] = !(this._mystified[idx] ?? false);
        this.render(false);
      });
    });

    // View item card (GM only)
    this.element.querySelectorAll("[data-action=view-item]").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        const idx = parseInt(btn.dataset.idx);
        await _openItemSheet(this._lootResult.items[idx]);
      });
    });

    // Whole-row click opens the same item view as the image button.
    bindRowClicks(this.element);

    // Currency mode buttons
    this.element.querySelectorAll("[data-action=set-currency]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        this._currencyMode = btn.dataset.mode;
        this.element.querySelectorAll("[data-action=set-currency]").forEach((b) => {
          b.classList.toggle("selected", b === btn);
        });
      });
    });

    // Save list for later
    this.element.querySelector("[data-action=save-list]")?.addEventListener("click", (e) => {
      e.preventDefault();
      this.#saveList();
    });
  }

  async #saveList() {
    const { items } = this._lootResult;
    if (!items.length) {
      ui.notifications.warn(game.i18n.localize("LOOTROLLER.quest.noItems"));
      return;
    }

    const name = await Dialog.prompt({
      title: game.i18n.localize("LOOTROLLER.savedLists.namePrompt"),
      content: `<div class="form-group">
        <label>${game.i18n.localize("LOOTROLLER.savedLists.nameLabel")}</label>
        <input type="text" name="listName" autofocus />
      </div>`,
      label: game.i18n.localize("LOOTROLLER.savedLists.save"),
      callback: (html) => html.find("[name=listName]").val().trim(),
      options: { width: 320 },
    }).catch(() => null);

    if (!name) return;
    await LootListManager.save(name, { items, coins: this._lootResult.coins ?? {}, category: "custom" });
    ui.notifications.info(game.i18n.format("LOOTROLLER.savedLists.saved", { name }));
  }

  static async #onSubmit(event, form, formData) {
    const app = /** @type {LotterySetupApp} */ (this);

    const { items } = app._lootResult;
    const lotteryItems = [];
    const stashItems   = [];

    for (let i = 0; i < items.length; i++) {
      const dest = app._destinations[i] ?? "lottery";
      if (dest === "discard") continue;

      // Serialize to plain object so we can apply the mystify state
      const raw        = items[i];
      const data       = raw.toObject?.() ?? { ...raw };
      const isMystified = app._mystified[i] ?? false;
      delete data._id;

      if (data.system) {
        const adapter = LootRoller.getAdapter?.();
        if (adapter?.applyMystification) {
          // Adapter handles system-specific identification fields.
          if (isMystified) {
            adapter.applyMystification(data);
          } else if (adapter.clearMystification) {
            adapter.clearMystification(data);
          }
        } else {
          // Fallback: dnd5e-style identification.
          data.system.identified = !isMystified;
          if (isMystified && data.system.unidentified !== undefined) {
            if (!data.system.unidentified.name) {
              data.system.unidentified.name = _unidentifiedLabel(data);
            }
          }
        }
      }

      if (dest === "lottery") lotteryItems.push(data);
      else if (dest === "stash") stashItems.push(data);
    }

    if (lotteryItems.length === 0 && stashItems.length === 0) {
      ui.notifications.warn("LOOTROLLER.warn.noItemsSelected", { localize: true });
      return;
    }

    const manager = new LotteryManager();
    game.modules.get("scorpious187s-loot-roller").lotteryManager = manager;

    const gmApp = new LotteryGMApp(manager);
    game.modules.get("scorpious187s-loot-roller").lotteryGMApp = gmApp;

    app.close();

    await manager.start({
      lotteryItems,
      stashItems,
      coins:        app._lootResult.coins,
      currencyMode: app._currencyMode,
    });

    gmApp.render(true);
  }
}

/** Open the module's item-detail popup for any item — document, plain object, or UUID-backed data. */
async function _openItemSheet(item) {
  if (!item) return;
  const uuid = item._sourceUuid ?? item.uuid;
  const doc  = uuid ? await fromUuid(uuid).catch(() => null) : null;
  // GM tool — show real details (mystified: false) regardless of the per-item mystify toggle.
  ItemDetailApp.show({ item: doc ?? item, mystified: false });
}
